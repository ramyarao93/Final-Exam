package main

import (
	"fmt"
	"os"
)

/*path of the file test.txt : you have to change it*/
var path = "names.txt"

func main() {

	p := []string{"Mohan\n", "Sravani\n", "Leo\n", "Surya Lanka\n", "Pradeep Jaligama\n", "Surya Lanka Naga\n", "Ratnakar\n"}
	fmt.Println(p)
	writeFile(p)

}

/* print errors*/
func isError(err error) bool {
	if err != nil {
		fmt.Println(err.Error())
	}

	return (err != nil)
}

/*writeFile write the data into file*/
func writeFile(p []string) {

	// open file using READ & WRITE permission
	var file, err = os.OpenFile(path, os.O_RDWR, 0644)

	if isError(err) {
		return
	}
	defer file.Close()

	// write into file
	_, err = file.WriteString(fmt.Sprintln(p))
	if isError(err) {
		return
	}

	// save changes
	err = file.Sync()
	if isError(err) {
		return
	}

	fmt.Println("==> done writing to file")
}
