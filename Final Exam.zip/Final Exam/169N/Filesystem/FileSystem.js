const fs = require('fs');
const util = require('util');

const write = util.promisify(fs.writeFile);
const read = util.promisify(fs.readFile);

// Create a variable representing the path to a .txt
const file1 = 'file1.txt';
const file2 = 'file2.txt';

function fileCompare(content1, content2) {

  //Compare the contents of both the files
  if (content1 === content2) {
    console.log('The files are identical')
  } else {
    console.log('The files are different')
  }
}

async function readWrite() {


  // Write "test" to the file
  await write(file1, 'my name is ramya');
  await write(file2, 'my name is not ramya')

  // Log the contents to console
  const contentsFromFile1 = await read(file1, 'utf8');
  const contentsFromFile2 = await read(file2, 'utf8');
  console.log(contentsFromFile1);
  console.log(contentsFromFile2);

  //Call the file compare by passing the values from both the files
  fileCompare(contentsFromFile1, contentsFromFile2);
}

readWrite();