
//Convering it to closures

for (var i = 0; i <= 5; i++) {
    setTimeout((function(i){
        return function(){console.log(i/1000);};
    })(i*1000));
}